/**
  Timing classes for profiling code execution.
*/

package fidocadj.timer;