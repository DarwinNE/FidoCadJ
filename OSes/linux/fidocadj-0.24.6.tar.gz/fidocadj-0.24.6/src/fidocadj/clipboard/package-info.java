/**
  Handle clipboard (copy/paste) operations.
*/

package fidocadj.clipboard;