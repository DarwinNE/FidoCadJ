/**
    Various general purpose classes for libraries.
*/

package fidocadj.librarymodel.utils;
