/**
    Package for handling events on the libraries.
    TODO: improve documentation of this package: what is the general
    philosophy? How are the classes interacting together? What is the
    relation between a "node" and an element in a directory?
*/
package fidocadj.librarymodel.event;
