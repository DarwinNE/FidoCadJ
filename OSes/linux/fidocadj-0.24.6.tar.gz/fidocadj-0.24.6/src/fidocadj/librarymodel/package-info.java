/** Package providing a model (database) as well as a representation of
    libraries.
    MacroDesc class (currently in the primitives package) will be moved
    here in the future.
*/
package fidocadj.librarymodel;
