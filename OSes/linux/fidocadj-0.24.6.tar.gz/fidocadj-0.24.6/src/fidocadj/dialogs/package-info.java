/**
    All the dialog windows (and related ancillary classes) of FidoCadJ.
*/

package fidocadj.dialogs;