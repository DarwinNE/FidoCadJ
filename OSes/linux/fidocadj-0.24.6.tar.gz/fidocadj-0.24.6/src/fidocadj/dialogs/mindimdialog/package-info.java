/** Package containing classes dealing with controlling the size of JDialog.
*/
package fidocadj.dialogs.mindimdialog;