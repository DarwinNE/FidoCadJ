/**
    Package containing classes for the printing options dialog, as well as
    the print preview.
*/
package fidocadj.dialogs.print;