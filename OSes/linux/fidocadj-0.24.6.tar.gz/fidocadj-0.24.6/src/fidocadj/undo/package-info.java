/** Everything which is needed to implement a undo buffer.
*/

package fidocadj.undo;