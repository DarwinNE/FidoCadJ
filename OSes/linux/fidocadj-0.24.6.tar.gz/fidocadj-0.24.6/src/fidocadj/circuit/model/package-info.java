/** <p>
 The package circuit.model contains model.DrawingModel class, which is the
 database of the graphical objects composing the drawing.</p>
*/
package fidocadj.circuit.model;
