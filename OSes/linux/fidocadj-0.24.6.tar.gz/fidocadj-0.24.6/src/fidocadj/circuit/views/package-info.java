/**<p>
 The package circuit.views contains the views for the view/model/controller
 pattern to represent the contents of the model.DrawingModel class.</p>
*/
package fidocadj.circuit.views;
