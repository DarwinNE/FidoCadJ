/**  Draw on nothing (nil), just to calculate image size: this is not so
    simple with text primitives...
*/

package fidocadj.graphic.nil;