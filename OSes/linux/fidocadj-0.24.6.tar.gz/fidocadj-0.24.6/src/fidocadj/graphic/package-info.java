/** Interfaces (and implementation, as sub-packages) of everything needed
    to draw on each kind of technology: Swing and Android, for example.
*/

package fidocadj.graphic;