/**  Draw on Swing Graphics2D objects.
*/

package fidocadj.graphic.swing;