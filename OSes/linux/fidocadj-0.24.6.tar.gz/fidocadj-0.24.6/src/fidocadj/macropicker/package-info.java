/**
    The macro picker tree on the right of the FidoCadJ application.
*/

package fidocadj.macropicker;
