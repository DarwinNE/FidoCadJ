/**
    Classes for handling the database (model) of the nodes in the macro
    picker tree.
*/

package fidocadj.macropicker.model;
