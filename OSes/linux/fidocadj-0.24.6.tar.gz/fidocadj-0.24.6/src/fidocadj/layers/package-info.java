/**
  Provides the layer description as well as some code of general interest
  handling layers. NOTE: this package will be merged with
  fidocadj.layermodel in the future.
*/

package fidocadj.layers;