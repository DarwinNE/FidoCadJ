/** Package for providing a model (database) for layers. Classes in the
    "layers" package will be moved here.
*/

package fidocadj.layermodel;