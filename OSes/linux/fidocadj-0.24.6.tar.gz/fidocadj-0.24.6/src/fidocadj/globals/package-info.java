/**
  Provide methods of general interest (usually, low level). Some classes define
  global constants as well as global variables.
*/

package fidocadj.globals;